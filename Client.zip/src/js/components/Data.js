var React = require('react');


var Data = React.createClass({

getInitialState: function() {
  return ({data:[]});
},
allData: function()
    {
      that=this;
      var obj = {};
      $.ajax({
        url: 'http://api.openweathermap.org/data/2.5/forecast?q='+this.refs.username.value+',uk&units=imperial&appid=c1de2d0d25c015fa905cf17c9b3e33e8',
        dataType: 'json',
        type: 'get',
        success: function(data)
        {
          this.setState({obj:data});
          console.log(data);
        }.bind(this),
        error: function(xhr, status, err) {
          console.error(err.toString());
        }.bind(this)
  });
  this.setState({data : obj});
      },
render: function()
{
  return(

    <div className="container mycontainerState">
    <h1 className="title" id="h1">Weather Forecast</h1>
      <div className="row main">
         <h2 className="title" id="h2">Enter city</h2>
            <hr />
      </div>
    
    <div className="main-login main-center">
        <input type="text" className="form-control" name="username" ref="username"  placeholder="Enter city" id=""/>
        <button type="button" onClick={this.allData} className="btn btn-primary btn-lg btn-block login-button"  >Search</button>
    
      </div>
      </div>
    );
}
});

module.exports = Data;
