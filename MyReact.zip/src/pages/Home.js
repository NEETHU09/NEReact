var React = require('react');
var NavBar = require('../../components/NavBar');
var CityWeather = require('../../components/CityWeather');

var Home = React.createClass({
  render: function() {
    return (
        <div>
            <NavBar/>
            <div className='container'>
                <MyCities/>
            </div>
        </div>
    );
  }
});

module.exports = Home;
